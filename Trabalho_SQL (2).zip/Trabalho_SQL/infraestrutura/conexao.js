import mysql from 'mysql2'

const conexao = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'Ab12cd34!',
  database: 'controle_usuarios'
});

conexao.connect((err) => {
  if (err) throw err;
  console.log(' Conectado ao MySQL!');
});

export default conexao;