class Tabelas {
    init(conexao) {
        this.conexao = conexao;
        this.criarTabelaUsuarios();
        this.criarTabelaTarefas();
    }

    criarTabelaUsuarios() {
        const sql = `
            CREATE TABLE IF NOT EXISTS usuarios (
                id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
                nome VARCHAR(100),
                email VARCHAR(50) UNIQUE NOT NULL,
                idade INT NOT NULL,
	            status ENUM('ativo','desativado') NOT NULL DEFAULT 'ativo',
	            senha VARCHAR(50) NOT NULL,
	            cargo ENUM('adm','usuario') NULL DEFAULT 'usuario'
            );
        `;

        this.conexao.query(sql, (error) => {
            if (error) {
                console.log("Deu erro:");
                console.log(error.message);
                return;
            }
            console.log("Tabela Usuarios criada com sucesso!");
        });
    }

    criarTabelaTarefas() {
        const sql = `

            CREATE TABLE IF NOT EXISTS tarefas (
	            id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
	            tarefa VARCHAR(100) NOT NULL,
	            status ENUM('em andamento','concluido','não iniciado') NOT NULL DEFAULT 'não iniciado'
	           
            );
        `;

        this.conexao.query(sql, (error) => {
            if (error) {
                console.log("Deu erro:");
                console.log(error.message);
                return;
            }
            console.log("Tabela Tarefas criada com sucesso!");
        });
    }
}

export default new Tabelas();
