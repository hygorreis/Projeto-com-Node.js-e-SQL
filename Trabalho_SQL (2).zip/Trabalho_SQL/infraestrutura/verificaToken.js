import jwt from 'jsonwebtoken';

const SECRET = 'XXXXXXXXXXX';

function verifyJWT(req, res, next) {
  const authHeader = req.headers['authorization'];

  if (!authHeader) {
    return res.status(401).json({ auth: false, message: 'Token não fornecido' });
  }

  const token = authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ auth: false, message: 'Token não fornecido' });
  }

  jwt.verify(token, SECRET, (err, decoded) => {
    if (err) {
      return res.status(500).json({ auth: false, message: 'Falha na autenticação do token' });
    }

    req.usuario = decoded; 
    next();
  });
}
export default verifyJWT;
