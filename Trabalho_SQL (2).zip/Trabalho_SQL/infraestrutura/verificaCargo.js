function verificaAdm(req, res, next) {
  if (req.usuario.cargo !== 'administrador') {
    return res.status(403).json({ auth: false, message: 'Acesso restrito a administradores' });
  }

  next();
}

export default verificaAdm;
