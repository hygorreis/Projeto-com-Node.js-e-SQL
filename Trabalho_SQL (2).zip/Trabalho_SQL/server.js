import express from 'express';
import cors from 'cors';
import conexao from './infraestrutura/conexao.js';
import tabela from './infraestrutura/tabelas.js';
import jwt, { decode } from 'jsonwebtoken';
import verifyJWT from './infraestrutura/verificaToken.js';
import verificaAdm from './infraestrutura/verificaCargo.js';
import dotenv from 'dotenv';
import bcrypt from 'bcryptjs';
import bodyParser from 'body-parser';





const app = express();

dotenv.config();

const SECRET = process.env.JWT_SECRET;

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));


tabela.init(conexao);



app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));


app.post('/login', (req, res) => {
  const { nome, senha } = req.body;

  console.log('Dados recebidos:', req.body);

  conexao.query(
    'SELECT * FROM usuarios WHERE nome = ?',
    [nome],
    (err, results) => {
      if (err) return res.status(500).json({ error: 'Erro no banco' });

      if (results.length === 0) {
        return res.status(401).json({ message: 'Usuário ou senha incorretos' });
      }

      const usuario = results[0];

      const senhaCorreta = senha === usuario.senha;

      if (!senhaCorreta) {
        return res.status(401).json({ message: 'Usuário ou senha incorretos' });
      }

      const token = jwt.sign({ id: usuario.id, nome: usuario.nome, cargo: usuario.cargo }, SECRET, { expiresIn: '1h' });

      return res.json({ auth: true, token});
    }
  );
});



app.get('/exibir_usuario', verifyJWT, verificaAdm,  (req, res) => {
  conexao.query('SELECT * FROM usuarios', (error, results) => {
    if (error) {
      res.status(500).send('Erro ao buscar usuários');
      return;
    }
    res.json(results);
  });
});


app.post('/cadastro_usuario', (req, res) => {

  const sql = 'INSERT INTO usuarios (nome, email, idade, status, senha, cargo) VALUES (?, ?, ?, ?, ?, ?)';

  const valores = [req.body.nome, req.body.email, req.body.idade, req.body.status, req.body.senha, req.body.cargo];

  conexao.query(sql, valores, (error, results) => {
    if (error) {
      console.error('Erro ao inserir usuário:', error);
      res.status(500).send('Erro ao inserir usuário');
      return;
    }
    console.log('Usuário inserido com ID:', results.insertId);
    res.status(201).send(`Usuário inserido com ID: ${results.insertId}`);
  });
});

app.delete('/deletar_usuario', (req, res) => {

  const sql = 'DELETE FROM usuarios WHERE id = ?;';

  const valores = [req.body.id];

  conexao.query(sql, valores, (error, results) => {
    if (error) {
      console.error('Erro ao deletar usuário:', error);
      res.status(500).send('Erro ao inserir usuário');
      return;
    }

    if (results.affectedRows === 0) {

      res.status(404).send('usuario não encontrado');

    } else {
      console.log('Usuário deletado com ID:', req.body.id);
      res.status(200).send(`Usuário deletado com ID: ${req.body.id}`);
    }

  });
});

app.put('/editar_usuario', (req, res) => {

  const sql = 'UPDATE usuarios SET nome = ?, email = ?, idade = ?, status = ?, senha = ?, cargo = ? WHERE id = ?';
  const valores = [req.body.nome, req.body.email, req.body.idade, req.body.status, req.body.senha, req.body.cargo, req.body.id];

  conexao.query(sql, valores, (error) => {
    if (error) {
      console.log("Erro no update do usuário", req.body.id);
      res.status(500).send(`Erro no update do usuário com ID: ${req.body.id}`);
      return;
    } else {
      console.log("Update realizado com sucesso", req.body.id);
      res.status(200).send(`Update realizado com ID: ${req.body.id}`);
    }
  });

});

app.get('/exibir_tarefa', (req, res) => {
  conexao.query('SELECT * FROM tarefas', (error, results) => {
    if (error) {
      res.status(500).send('Erro ao buscar tarefas');
      return;
    }
    res.json(results);
  });
});


app.post('/cadastrar_tarefa', (req, res) => {

  const sql = 'INSERT INTO tarefas (tarefa, status) VALUES (?, ?)';

  const valores = [req.body.tarefa, req.body.status];

  conexao.query(sql, valores, (error, results) => {

    if (error) {
      console.error('erro ao inserir tarefa: ', error);
      res.status(500).send('erro ao inserir tarefa');
    }
    console.log('tarefa inserida com ID: ', results.insertId);
    res.status(201).send(`tarefa inserida com ID: ${results.insertId}`);
  });

});

app.put('/editar_tarefa', (req, res) => {

  const sql = 'UPDATE tarefas SET tarefa = ?, status = ? WHERE id = ?';
  const valores = [req.body.tarefa, req.body.status, req.body.id];

  conexao.query(sql, valores, (error) => {
    if (error) {
      console.log("Erro no update da tarefa", req.body.id);
      res.status(500).send(`Erro no update da tarefa com ID: ${req.body.id}`);
      return;
    } else {
      console.log("Update realizado com sucesso", req.body.id);
      res.status(200).send(`Update realizado com ID: ${req.body.id}`);
    }
  });

});

app.delete('/deletar_tarefa', (req, res) => {

  const sql = 'DELETE FROM tarefas WHERE id = ?;';

  const valores = [req.body.id];

  conexao.query(sql, valores, (error, results) => {
    if (error) {
      console.error('Erro ao deletar tarefa:', error);
      res.status(500).send('Erro ao inserir usuário');
      return;
    }

    if (results.affectedRows === 0) {

      res.status(404).send('tarefa não encontrado');

    } else {
      console.log('tarefa deletado com ID:', req.body.id);
      res.status(200).send(`tarefa deletada com ID: ${req.body.id}`);
    }

  });
});

app.listen(3001, (erro) => {
  if (erro) {
    console.log("Deu erro:", erro);
    return;
  }
  console.log("Servidor rodando na porta 3001");
});
