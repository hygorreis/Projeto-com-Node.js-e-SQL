import {BrowserRouter, Route, Routes} from 'react-router-dom'
import Login from './pages/Login/login.jsx'
import Home from './pages/Home/index.jsx'
import Update from './pages/Update/update.jsx'
import Principal from './pages/Principal/principal.jsx'
import Tarefas from './pages/Tarefas/tarefas.jsx'
import Update_Tarefas from './pages/Update_Tarefas/Update_Tarefas.jsx'


function App() {

    return(

        <BrowserRouter>

            <Routes>

                <Route  path='/' element={<Login/>}/>
                <Route  path='/Cadastro' element={<Home/>}/>
                <Route  path='/Update' element={<Update/>}/>
                <Route  path='/Principal' element={<Principal/>}/>
                <Route path='/Tarefas' element={<Tarefas/>}/>
                <Route path='/Update_Tarefas' element={<Update_Tarefas/>}/>
                <Route  path='*' element={<h1> Not Foud </h1>}/>
                
            </Routes>

        </BrowserRouter>

    )
}

export default App