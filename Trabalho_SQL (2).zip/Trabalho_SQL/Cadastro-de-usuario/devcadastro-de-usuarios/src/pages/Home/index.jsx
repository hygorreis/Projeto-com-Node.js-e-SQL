import { useEffect, useState, useRef } from 'react';
import './style.css';
import Lixeira from '../../assets/Lixeira.png';
import api from '../../services/api';

function Home() {

  const [usuarios, setUsuarios] = useState([]);

  const inputNome = useRef();
  const inputEmail = useRef();
  const inputIdade = useRef();
  const inputStatus = useRef();
  const inputSenha = useRef();
  const inputCargo = useRef();

  async function getUsuarios() {

     try {
    const token = localStorage.getItem('token');
    if (!token) {
      alert('Você precisa fazer login.');
      return;
    }

    const response = await api.get('/exibir_usuario', {
      headers: {
        Authorization: `Bearer ${token}`
      }
    });

    setUsuarios(response.data);
  } catch (error) {
    console.error('Erro ao buscar usuários:', error);
    alert('Erro ao buscar usuários, verifique seu login.');
  }
}

  async function postUsuarios() {

    await api.post('/cadastro_usuario', {

      nome: inputNome.current.value,
      email: inputEmail.current.value,
      idade: inputIdade.current.value,
      status: inputStatus.current.value,
      senha: inputSenha.current.value,
      cargo: inputCargo.current.value, 

    })
    getUsuarios();
  }

  async function deleteUsuarios(id) {

    await api.delete('/deletar_usuario', { data: { id } });

    getUsuarios();
  }

  useEffect(() => {
    getUsuarios();
  }, []);

  return (
    <div className='container1'>
      <form>
        <h1>CADASTRO DE USUÁRIOS</h1>

        <input placeholder='Nome' name='nome' type='text' ref={inputNome} />
        <input placeholder='E-mail' name='email' type='email' ref={inputEmail} />
        <input placeholder='Idade' name='idade' type='number' ref={inputIdade} />
        <input placeholder='Status' name='status' type='text' ref={inputStatus} />
        <input placeholder='Senha' name='senha' type="password" ref={inputSenha} />
        <input placeholder='Cargo' name='cargo' type="text" ref={inputCargo} />
        <button type='button' onClick={postUsuarios}>CADASTRAR</button>
      </form>

      {usuarios.map((usuario) => (
        <div key={usuario.id} className='card'>
          <div>
            <p>ID: {usuario.id}</p>
            <p>Nome: {usuario.nome}</p>
            <p>E-mail: {usuario.email}</p>
            <p>Idade: {usuario.idade}</p>
            <p>Status: {usuario.status}</p>
            <p>Senha: {usuario.senha}</p>
            <p>Cargo: {usuario.cargo}</p>
          </div>
          <button onClick={() => deleteUsuarios(usuario.id)}>
            <img src={Lixeira} alt="Excluir" />
          </button>
        </div>
      ))}
    </div>
  );
}


export default Home;
