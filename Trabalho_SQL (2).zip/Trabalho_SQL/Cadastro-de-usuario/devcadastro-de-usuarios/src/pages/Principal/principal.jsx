import { Link } from 'react-router-dom';
import './principal.css'


function Principal() {


    return (

        <div className='container1'>

            <div className='id1'> <h1> Olá Adiministrador </h1>  </div>

            <div className='container2'>

                <Link to="/Cadastro">
                    <button> CADASTRAR USUÁRIO</button>
                </Link>

                <Link to="/Update">
                    <button>  EDITAR USUÁRIO </button>
                </Link>

                <Link to="/Tarefas">
                    <button> CADASTRAR TAREFAS </button>
                </Link>

                <Link to="/Update_Tarefas">
                    <button> EDITAR TAREFAS </button>
                </Link>

            </div>

        </div>



    );
}

export default Principal;