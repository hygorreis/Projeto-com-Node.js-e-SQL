import { useRef } from 'react';
import api from '../../services/api';
import './login.css';

function Login() {
    const inputNome = useRef();
    const inputSenha = useRef();

    async function postUsuarios(e) {
        e.preventDefault();

        try {
            const response = await api.post('/login', {
                nome: inputNome.current.value,
                senha: inputSenha.current.value,
            });

            localStorage.setItem('token', response.data.token);

            window.location.href = '/Principal';

        } catch (err) {
            alert('Login inválido');
            console.error(err);
        }
    }

    return (
        <div className="container1">
            <form>
                <h1> LOGIN </h1>

                <input name="nome" type="text" ref={inputNome} placeholder="Nome" />
                <input name="senha" type="password" ref={inputSenha} placeholder="Senha" />
                <button onClick={postUsuarios}>ENTRAR</button>
            </form>
        </div>
    );
}

export default Login;
