import { useRef, useState, useEffect } from 'react'
import api from '../../services/api'
import Lixeira from '../../assets/Lixeira.png'
import './tarefas.css'


function Tarefas() {

    const [tarefas, setTarefas] = useState([]);

    const inputTarefa = useRef();
    const inputStatus = useRef();

 async function getTarefas() {
    try {
      const response = await api.get('/exibir_tarefa');
      setTarefas(response.data);
    } catch (error) {
      console.error('Erro ao buscar usuários:', error);
    }
  }


    async function postTarefas() {

        await api.post('cadastrar_tarefa', {

            tarefa: inputTarefa.current.value,
            status: inputStatus.current.value
        })

        getTarefas();

    }

    async function deleteTarefa(id) {

        await api.delete('/deletar_tarefa', { data: { id } });

        getTarefas();

    }

    useEffect(() => {
        getTarefas();
    }, []);

    return (

        <div className='container1'>


            <form>

                <h1> CADASTRAR TAREFA </h1>

                <input placeholder='Digite o nome da tarefa' name='tarefa' type="text" ref={inputTarefa} />
                <label htmlFor="opcao">Status:</label>
                <select id="opcao" name="opcao" required ref={inputStatus} defaultValue="">
                    <option value="" disabled>Selecione uma opção</option>
                    <option value="1">em andamento</option >
                    <option value="2">concluido</option>
                    <option value="3">não iniciado</option>
                </select>

                <button type='button' onClick={postTarefas}> CADASTRAR </button>

            </form>

            {tarefas.map((tarefas) => (
                <div key={tarefas.id} className='card'>
                    <div>
                        <p>id: {tarefas.id}</p>
                        <p>tarefa: {tarefas.tarefa}</p>
                        <p>Status: {tarefas.status}</p>
                    </div>
                    <button onClick={() => deleteTarefa(tarefas.id)}>
                        <img src={Lixeira} alt="Excluir" />
                    </button>
                </div>
            ))}

        </div>


    );
}

export default Tarefas;