import { useRef } from 'react';
import api from '../../services/api';
import './update.css'


function Update() {

    const inputID = useRef();
    const inputNome = useRef();
    const inputEmail = useRef();
    const inputIdade = useRef();
    const inputStatus = useRef();
    const inputSenha = useRef();
    const inputCargo = useRef();


    async function putUsuarios() {

        await api.put('/editar_usuario', {

            id : inputID.current.value,
            nome: inputNome.current.value,
            email: inputEmail.current.value,
            idade: inputIdade.current.value,
            status: inputStatus.current.value,
            senha: inputSenha.current.value,
            cargo: inputCargo.current.value,

        })

    }

    return (

        <div className='container1'>
            <form>
                <h1>ALTERAR USUÁRIOS</h1>
                <input placeholder='ID' name='id' type='text' ref={inputID} />
                <input placeholder='Nome' name='nome' type='text' ref={inputNome} />
                <input placeholder='E-mail' name='email' type='email' ref={inputEmail} />
                <input placeholder='Idade' name='idade' type='number' ref={inputIdade} />
                <input placeholder='Status' name='status' type='text' ref={inputStatus} />
                <input placeholder='Senha' name='senha' type="password" ref={inputSenha} />
                <input placeholder='Cargo' name='cargo' type="text" ref={inputCargo} />
                <button type='button' onClick={putUsuarios}>ALTERAR</button>
            </form>

        </div>
    );

}

export default Update;
