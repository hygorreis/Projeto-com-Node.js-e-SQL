import { useRef } from 'react';
import api from '../../services/api';
import './Update_Tarefas.css'


function Update_Tarefas() {

    const inputID = useRef();
    const inputTarefa = useRef();
    const inputStatus = useRef();



    async function putTarefas() {

        await api.put('/editar_tarefa', {

            id: inputID.current.value,
            tarefa: inputTarefa.current.value,
            status: inputStatus.current.value

        })

    }

    return (

        <div className='container1'>
            <form>
                <h1>ALTERAR TAREFAS</h1>
                <input placeholder='ID' name='id' type='text' ref={inputID} />
                <input placeholder='Tarefa' name='tarefa' type='text' ref={inputTarefa} />
               <label htmlFor="opcao">Status:</label>
                <select id="opcao" name="opcao" required ref={inputStatus} defaultValue="">
                    <option value="" disabled>Selecione uma opção</option>
                    <option value="1">em andamento</option >
                    <option value="2">concluido</option>
                    <option value="3">não iniciado</option>
                </select>
                
                <button type='button' onClick={putTarefas}>ALTERAR</button>
            </form>

        </div>
    );

}

export default Update_Tarefas;
